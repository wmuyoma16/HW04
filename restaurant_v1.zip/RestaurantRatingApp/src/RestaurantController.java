import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// The Controller coordinates interactions
// between the View and Model

public class RestaurantController {
	
	private RestaurantView theView;
	private RestaurantModel theModel;
	
	public RestaurantController(RestaurantView theView, RestaurantModel theModel) {
		this.theView = theView;
		this.theModel = theModel;
		
		// Tell the View that when ever the save button
		// is clicked to execute the actionPerformed method in the Listener class below
		this.theView.addSaveListener(new SaveButtonListener());
	}
	
	class SaveButtonListener implements ActionListener{

		public void actionPerformed(ActionEvent e) {
			
			String name, address, notes, rating;
			
			// here you can check if any text fields are empty..
			name = theView.getName();
			address = theView.getAddress();
			notes = theView.getNotes();
			rating = theView.getRating();
			
			MyUtilities.saveStringToFile("rest_file.txt",
					"Restaurant Name: " + name + "<br>" +
					"Restaurant Address: " + address + "<br>" +
					"User Notes: " + notes + "<br>" +
					"User Star Rating: " + rating + "<br>" + "\n--------------\n<br>");
			
			theView.setPrevReview();
		}
	} //end listener inner class
}