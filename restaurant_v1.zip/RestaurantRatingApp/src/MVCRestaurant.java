public class MVCRestaurant {
    
    public static void main(String[] args) {
    	
    	RestaurantView theView = new RestaurantView();
        
    	RestaurantModel theModel = new RestaurantModel();
        
        RestaurantController theController = new RestaurantController(theView,theModel);
        
        theView.setVisible(true);
        
    }
}