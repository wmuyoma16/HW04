// The Model performs all the data storing needed
// and that is it. It doesn't know the View
// exists
 
public class RestaurantModel {
 
    // Holds the list of restaurants
    // entered in the view
	// we can keep this example simple by just storing the restaurants in text file
	//and not do anything here
     
}
