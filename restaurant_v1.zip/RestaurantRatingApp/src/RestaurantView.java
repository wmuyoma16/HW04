// This is the View
// Its only job is to display what the user sees
// It performs no calculations, but instead passes
// information entered by the user to whomever needs
// it. 

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.*;

public class RestaurantView extends JFrame{

	private JTextField name  = new JTextField(10);
	private JTextField address = new JTextField(10);
	private JTextField notes = new JTextField(10);
	private JTextField rating = new JTextField(10);	
	private JButton saveButton = new JButton("Save Restaurant");
	private JLabel additionLabel = new JLabel("<html>Visited Restaurants Review:<br></html>");
	private JLabel jl = new JLabel(" ");  
	
	String stars[] = { "5 star", "4 star", "3 star", "2 star", "1 star"};
	JComboBox rating_jcb = new JComboBox(stars);
	
	RestaurantView(){
		
		// Sets up the view and adds the components
		
		//JPanel restPanel = new JPanel(new GridLayout(0,1));
		JPanel restPanel = new JPanel();
		
		restPanel.setLayout(new BoxLayout(restPanel, BoxLayout.Y_AXIS));
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(400, 400);
		
		restPanel.add(new JLabel("Enter Restaurant Details below and click Save: "));

		restPanel.add(new JLabel("Restaurant Name: "));
		restPanel.add(name);
		restPanel.add(new JLabel("Restaurant Address: "));
		restPanel.add(address);
		restPanel.add(new JLabel("User Notes: "));
		restPanel.add(notes);
		restPanel.add(new JLabel("User Star Rating: "));
		//restPanel.add(rating);
		restPanel.add(rating_jcb);
		restPanel.add(saveButton);
		restPanel.add(additionLabel);
		restPanel.add(jl);
		
		JScrollPane scroller = new JScrollPane(jl, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroller.setPreferredSize(new Dimension(400, 600));
		restPanel.add(scroller);
		
		
		this.add(restPanel);
		
		File testFile = new File("rest_file.txt");
		if (testFile.exists()) {
			jl.setText("<html>" +
					MyUtilities.getStringFromFile("rest_file.txt")
					+ "<br>" + "</html>");
		}
			
		// End of setting up the components --------
	}

//-------------------------------------	
	public String getName(){
		
		return name.getText();
		
	}
	
	public String getAddress(){
		
		return address.getText();
		
	}

	public String getNotes(){
		
		return notes.getText();
		
	}
	
	public String getRating(){
		
		//return rating.getText();
		return (String)rating_jcb.getSelectedItem();
		
	}
//-------------------------------------
	public void setPrevReview(){
		
		jl.setText("<html>" +
				MyUtilities.getStringFromFile("rest_file.txt")
				+ "<br>" + "</html>");
		
	}
	
	// If the save Button is clicked execute a method
	// in the Controller named actionPerformed
	
	void addSaveListener(ActionListener listenForSaveButton){
		
		saveButton.addActionListener(listenForSaveButton);
	}
	
	// Open a popup that contains the error message passed
	void displayErrorMessage(String errorMessage){
		
		JOptionPane.showMessageDialog(this, errorMessage);
	}
	
}